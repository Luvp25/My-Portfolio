function createNewCard() {
  /* Step 1: Create a new div element and assign it to a variable called cardElement. */
  const cardElement = document.createElement("div");

  /* Step 2: Add the "card" class to the variable 'cardElement'. */
  cardElement.classList.add('card');

  /* Step 3: Write the HTML for the children of the card element (card-down and card-up) as a normal string and assign it as the innerHTML of cardElement. */
  cardElement.innerHTML = `
    <div class="card-down"></div>
    <div class="card-up"></div>
  `;

  /* Step 4: Return the cardElement. */
  return cardElement;
}

function appendNewCard(parentElement) {
  /* Step 1: Create a new card by calling createNewCard() and assign it to a variable named cardElement. */
  const cardElement = createNewCard();

  /* Step 2: Append the card element to the parentElement (making the card element a "child"). */
  parentElement.appendChild(cardElement);

  /* Step 3: Return the card element. */
  return cardElement;
}

function shuffleCardImageClasses() {
  /* Step 1: Create a new array that contains two of each image class string in order. */
  const cardClasses = [
    'appa', 'appa',
    'aang', 'aang',
    'sokka', 'sokka',
    'momo', 'momo',
    'bumi', 'bumi',
    'katara', 'katara',
    'zuko', 'zuko',
    'toph', 'toph'
  ];

  /* Step 2: Shuffle the array using Underscore.js's shuffle method. */
  const shuffledClasses = _.shuffle(cardClasses);

  /* Step 3: Return the shuffled array of class names. */
  return shuffledClasses;
}

function createCards(parentElement, shuffledImageClasses) {
  /* Step 1: Make an empty array to hold our card objects. */
  const cardObjects = [];

  /* Step 2: Write a for loop that loops 16 times to create the 16 cards we need. */
  for (let i = 0; i < shuffledImageClasses.length; i++) {
    /* Step 2(a): Use appendNewCard to create/append a new card and store the result in a variable. */
    const cardElement = appendNewCard(parentElement);

    /* Step 2(b): Add an image class to the new card element using shuffledImageClasses[i]. */
    cardElement.classList.add(shuffledImageClasses[i]);

    /* Step 2(c): Append a new object to the card object array. The object should contain the following properties:
        "index" -- Which iteration of the loop this is.
        "element" -- The DOM element for the card.
        "imageClass" -- The string of the image class on the card. */
    cardObjects.push({
      index: i,
      element: cardElement,
      imageClass: shuffledImageClasses[i]
    });

    // Add click event listener to each card
    cardElement.addEventListener('click', function() {
      if (!cardElement.classList.contains('flipped')) {
        flipCard(cardElement);
      }
    });
  }

  /* Step 3: Return the array of 16 card objects. */
  return cardObjects;
}

function flipCard(cardElement) {
  /* Add the flipped class to the card element to rotate it and show the image. */
  cardElement.classList.add('flipped');

  /* Create a card object for the flipped card */
  const flippedCardObject = {
    element: cardElement,
    imageClass: cardElement.classList[1] // Get the image class from the card's class list
  };

  /* Call onCardFlipped with the newly flipped card */
  onCardFlipped(flippedCardObject);
}

function doCardsMatch(cardObject1, cardObject2) {
  /* Step 1: Determine if two cards match based on their imageClass property. */
  return cardObject1.imageClass === cardObject2.imageClass;
}

let counters = {}; // Object to keep track of counters

function incrementCounter(counterName, parentElement) {
  /* Step 1: If the 'counterName' property is not defined in the 'counters' object, initialize it with a value of 0. */
  if (!counters[counterName]) {
    counters[counterName] = 0;
  }

  /* Step 2: Increment the counter for 'counterName'. */
  counters[counterName]++;

  /* Step 3: Change the HTML within 'parentElement' to display the new counter value. */
  const counterElement = document.getElementById(counterName + '-count');
  if (counterElement) {
    counterElement.textContent = counters[counterName];
  }
}

let lastCardFlipped = null; // Variable to track the last flipped card

function onCardFlipped(newlyFlippedCard) {
  /* Step 1: Use the 'incrementCounter' function to add one to the flip counter UI. */
  incrementCounter('flip', document.getElementById('ui-container'));

  /* Step 2: If 'lastCardFlipped' is null (this is the first card flipped), update 'lastCardFlipped' and return. */
  if (lastCardFlipped === null) {
    lastCardFlipped = newlyFlippedCard;
    return;
  }

  /* If the above condition was not met, we know there are two cards flipped that should be stored in 'lastCardFlipped' and 'newlyFlippedCard', respectively. */
  if (!doCardsMatch(lastCardFlipped, newlyFlippedCard)) {
    // Cards don't match, flip them back
    setTimeout(() => {
      lastCardFlipped.element.classList.remove('flipped');
      newlyFlippedCard.element.classList.remove('flipped');
      lastCardFlipped = null; // Reset lastCardFlipped
    }, 1000);
  } else {
    // Cards match, add a glow effect
    lastCardFlipped.element.classList.add('glow');
    newlyFlippedCard.element.classList.add('glow');

    // Increment the match counter
    incrementCounter('match', document.getElementById('ui-container'));

    // Check for win condition
    if (counters['match'] === 8) {
      // Play win audio
      winAudio.play();
    }

    // Reset lastCardFlipped
    lastCardFlipped = null;
  }
}


function resetGame() {
  /* Step 1: Get the card container by its id and store it in a variable. */
  const cardContainer = document.getElementById('card-container');

  /* Step 2: Clear all the cards by using a while loop to remove the first child of the card container as long as a first child exists. */
  while (cardContainer.firstChild) {
    cardContainer.removeChild(cardContainer.firstChild);
  }

  /* Step 3: Get the HTML elements that display the flip and match counts and reset their inner text to 0. */
  document.getElementById('flip-count').textContent = '0';
  document.getElementById('match-count').textContent = '0';

  /* Step 4: Reassign the value of the `counters` dictionary to an empty object. */
  counters = {};

  /* Step 5: Set lastCardFlipped back to null. */
  lastCardFlipped = null;

  /* Step 6: Set up a new game. */
  const shuffledClasses = shuffleCardImageClasses();
  createCards(document.getElementById('card-container'), shuffledClasses);
}
